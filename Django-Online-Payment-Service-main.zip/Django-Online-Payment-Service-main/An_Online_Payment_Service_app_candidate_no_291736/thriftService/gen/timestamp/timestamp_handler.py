import datetime

class TimestampHandler:
    def getCurrentTimestamp(self):
        return str(datetime.datetime.now())
