service TimestampService {
    string getCurrentTimestamp();
}

