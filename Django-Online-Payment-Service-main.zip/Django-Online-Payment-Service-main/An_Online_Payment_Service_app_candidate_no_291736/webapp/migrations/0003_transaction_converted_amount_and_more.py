

from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("webapp", "0002_user_balance_delete_accountbalance"),
    ]

    operations = [
        migrations.AddField(
            model_name="transaction",
            name="converted_amount",
            field=models.DecimalField(
                blank=True, decimal_places=2, max_digits=10, null=True
            ),
        ),
        migrations.AddField(
            model_name="transaction",
            name="exchange_currency",
            field=models.CharField(blank=True, max_length=15, null=True),
        ),
        migrations.AddField(
            model_name="transaction",
            name="exchange_rate",
            field=models.DecimalField(decimal_places=6, default=1, max_digits=10),
        ),
    ]
